//
//  OpenGLES_Ch2_1AppDelegate.m
//  OpenGLES_Ch2_1
//
//  Created by frank.Zhang on 11/02/2018.
//  Copyright © 2018 Frank.Zhang. All rights reserved.
//

#import "OpenGLES_Ch2_1AppDelegate.h"
#import "OpenGLES_Ch2_1ViewController.h"
@implementation OpenGLES_Ch2_1AppDelegate
@synthesize window = _window;

//- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
//    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
//    OpenGLES_Ch2_1ViewController * mainVc = [[OpenGLES_Ch2_1ViewController alloc]initWithNibName:@"OpenGLES_Ch2_1ViewController" bundle:nil];
//    UINavigationController *navVc = [[UINavigationController alloc]initWithRootViewController:mainVc];
//    navVc.title = @"OpenGLES_Ch2_1ViewController";
//    self.window.rootViewController = navVc;
//    [self.window makeKeyAndVisible];
//    return YES;
//}
-(void)applicationWillResignActive:(UIApplication *)application{
    
}

-(void)applicationDidEnterBackground:(UIApplication *)application{
    
}

-(void)applicationWillEnterForeground:(UIApplication *)application{
    
}

-(void)applicationDidBecomeActive:(UIApplication *)application{
    
}

-(void)applicationWillTerminate:(UIApplication *)application{
    
}
@end
