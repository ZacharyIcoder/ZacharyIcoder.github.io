//
//  OpenGLES_Ch2_1AppDelegate.h
//  OpenGLES_Ch2_1
//
//  Created by frank.Zhang on 11/02/2018.
//  Copyright © 2018 Frank.Zhang. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface OpenGLES_Ch2_1AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong,nonatomic)UIWindow *window;
@end
