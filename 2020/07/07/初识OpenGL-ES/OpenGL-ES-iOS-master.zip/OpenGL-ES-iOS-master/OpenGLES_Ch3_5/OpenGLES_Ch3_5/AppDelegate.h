//
//  AppDelegate.h
//  OpenGLES_Ch3_5
//
//  Created by frank.zhang on 2019/1/18.
//  Copyright © 2019 Frank.zhang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

