//
//  OpenGLES_Ch2_2AppDelegate.m
//  OpenGLES_Ch2_2
//
//  Created by frank.Zhang on 21/03/2018.
//  Copyright © 2018 Frank.Zhang. All rights reserved.
//

#import "OpenGLES_Ch2_2AppDelegate.h"

@implementation OpenGLES_Ch2_2AppDelegate
@synthesize window = _window;

-(void)applicationWillResignActive:(UIApplication *)application{
    
}

-(void)applicationDidEnterBackground:(UIApplication *)application{
    
}

-(void)applicationWillEnterForeground:(UIApplication *)application{
    
}

-(void)applicationDidBecomeActive:(UIApplication *)application{
    
}

-(void)applicationWillTerminate:(UIApplication *)application{
    
}

@end
