//
//  main.m
//  OpenGLES_Ch2_2
//
//  Created by frank.Zhang on 20/03/2018.
//  Copyright © 2018 Frank.Zhang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OpenGLES_Ch2_2AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([OpenGLES_Ch2_2AppDelegate class]));
    }
}
