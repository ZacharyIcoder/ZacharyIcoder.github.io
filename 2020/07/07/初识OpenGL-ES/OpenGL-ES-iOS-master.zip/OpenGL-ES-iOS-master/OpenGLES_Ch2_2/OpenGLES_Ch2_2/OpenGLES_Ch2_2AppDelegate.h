//
//  OpenGLES_Ch2_2AppDelegate.h
//  OpenGLES_Ch2_2
//
//  Created by frank.Zhang on 21/03/2018.
//  Copyright © 2018 Frank.Zhang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OpenGLES_Ch2_2AppDelegate : UIResponder<UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
